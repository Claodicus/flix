//
//  MovieGridCell.swift
//  Flix
//
//  Created by Patrick Brothers on 3/4/22.
//

import UIKit

class MovieGridCell: UICollectionViewCell {
    
    @IBOutlet weak var posterView: UIImageView!
}
